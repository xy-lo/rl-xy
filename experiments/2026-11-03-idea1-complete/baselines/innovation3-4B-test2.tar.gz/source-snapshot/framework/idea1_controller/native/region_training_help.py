"""Conservative training tail help between compatible completed TP2 regions.

Heterogeneous regions keep their original quorum/gradient protocol. A singleton
TP2 donor may move an unstarted, advantage-ready TP2 batch to a completed
completed TP2 pair. For a heterogeneous receiver, every member must first
finish its canonical TP2 restoration. The receiver accumulates into its already restored TP2
buffer; the unchanged global SUM includes it once. Larger TP regions never
silently execute a TP2 body. Native record transport is charged in full.
"""
from dataclasses import asdict
from training_coop import TrainingCoopRuntime
from .context import digest

class SingletonTrainingHelp:
    def training_jobs(self,w):
        r=self.region_of[w]
        if len(self.region_members[r])!=1:
            yield from super().training_jobs(w);return
        if r not in self.region_programs:self._build_region_program(r)
        for stage,tids,steps,job in self.region_programs[r]:
            if stage=='gradient_zero':
                from collections import deque
                # Reached only after both teacher passes and advantage finish.
                self.train_queues[w]=deque(x[3] for x in self.region_programs[r] if x[0]=='training')
            if stage=='training':
                if self.batch_state[job['batch_id']]!='queued':continue
                self.train_queues[w].remove(job)
                self.pending_batch[w]=job;self.batch_state[job['batch_id']]='running'
            yield stage,tids,steps

    def training_help_choice(self,w):
        if w!=self.region_of[w] or len(self.region_members[w])!=1:return None
        if self.leased(w) or len(self.done)!=len(self.ids) or not self.train_queues.get(w):return None
        free=[j for j in self.trained if j!=w and all(v in self.trained for v in self.region_members[self.region_of[j]])
              and self.waiting[j] and j not in self.services and j not in self.helper_jobs and not self.leased(j)]
        if not free:return None
        def hops(j):return max(abs(a//6-b//6)+abs(a%6-b%6) for a,b in zip(self.rep[w].ranks,self.rep[j].ranks))
        dst=min(free,key=lambda j:(hops(j),j))
        job=max(self.train_queues[w],key=lambda x:(x['estimate_local_ns'],x['index']))
        # All token/advantage data is already observed, so this check uses no
        # future EOS. A positive service margin also avoids tiny bad transfers.
        size=job['payload_bytes_per_lane'];transport=size/self.op.hw.d2d_bytes_per_ns_per_direction*max(1,hops(dst))+2*size/self.op.hw.dram_bytes_per_ns
        if job['estimate_local_ns']<=transport*1.05:return None
        return dst,job

    def dispatch_training(self,w):
        choice=self.training_help_choice(w)
        if choice is None:return None
        dst,job=choice;self.train_queues[w].remove(job);bid=job['batch_id']
        assert self.batch_state[bid]=='queued'
        # Discard source quorum wrappers and bind the portable operator body
        # to the destination's TP2 communicator. No source rank remains.
        body=[dict(s) for s in job['steps'] if s['kind'] in ('local','AR')]
        assert all(not set(s)&{'src','dst','ranks'} for s in body)
        for s in body:
            if s['kind']=='AR':s.pop('group',None) # attached worker communicator is TP2
        remote=dict(job,steps=body,program_sha256=digest(dict(repeat=1,steps=body)))
        self.batch_state[bid]='transferring';self.helper_jobs[dst]=remote
        self.move_id+=1;tx=dict(id=self.move_id,kind='training_batch',src=w,dst=dst,batch_id=bid,
            tids=job['tids'],bytes_per_lane=job['payload_bytes_per_lane'],consumed=set(),start_tick=self.tick)
        self.services[w]=self.services[dst]=tx;self.waiting[w]=False
        return {'steps':[self.wake(dst,self.rep[w].ranks[0]),self.rpc(w,'sample_run')]}

    def commit_stage(self,w):
        pending=self.pending_stage.get(w)
        if pending and pending[0]=='training' and w in self.helper_jobs:
            job=self.helper_jobs[w];batch=[self.items[t] for t in job['tids']]
            cert=asdict(self.memory.phase('training',2,batch));assert cert['peak_bytes']<=self.op.capacity
            self.actual_allocation_events.append(dict(certificate_tick=pending[2],region=w,stage='training',tp=2,
                items=job['tids'],**cert,start_tick=pending[2],end_tick=self.tick,remote_from=job['home']))
            TrainingCoopRuntime.commit_stage(self,w)
            self.batch_executions[-1].update(training_tp=2,physical_ranks=self.rep[w].ranks,remote=True)
            return
        return super().commit_stage(w)

class RegionalTrainingCooperator:
    def __init__(self,c):self.c=c
    def propose_unstarted_batch_takeovers(self,region_id,snapshot):
        c=self.c;k=c.kernel
        if region_id!=c.region_id(c.w) or not c.is_step() or c.w in k.services:return ()
        result=[];choice=k.training_help_choice(c.w)
        if choice:
            dst,job=choice
            result.append(c.propose('training_transfer',20,'TAKE_TRAIN_BATCH',peer=dst,tids=job['tids'],batch_id=job['batch_id']))
        if c.w in k.helper_jobs:
            result.append(c.propose('run_remote_batch',30,'START_BACKWARD',tids=k.helper_jobs[c.w]['tids']))
        return tuple(result)
